document.addEventListener('DOMContentLoaded', () => {
  const notificationsDiv = document.getElementById('notifications');
  
  const alerts = [
    "تنبيه: تم رصد زلزال بقوة 6.2 على مقياس ريختر.",
    "تنبيه: تسونامي متوقع في السواحل الغربية. احذروا الأمواج العالية.",
    "تنبيه: نشاط بركاني في جبل النار. يرجى الابتعاد عن المنطقة.",
    "تنبيه: أمطار غزيرة تؤدي إلى فيضانات في منطقة الجنوب."
  ];

  let alertIndex = 0;

  setInterval(() => {
    if (alertIndex < alerts.length) {
      const alertMessage = document.createElement('p');
      alertMessage.textContent = alerts[alertIndex];
      alertMessage.style.background = "#ffeb3b"; // خلفية صفراء للتنبيه
      alertMessage.style.padding = "10px";
      alertMessage.style.borderRadius = "5px";
      alertMessage.style.marginBottom = "10px";
      notificationsDiv.appendChild(alertMessage);
      alertIndex++;
    } else {
      alertIndex = 0;
    }
  }, 10000);
});
document.addEventListener('DOMContentLoaded', () => {
  const loadInfoButton = document.getElementById('loadInfo');
  const contentDiv = document.getElementById('content');
  const sendAlertButton = document.getElementById('sendAlert');

  loadInfoButton.addEventListener('click', () => {
    contentDiv.innerHTML = `
      <h3>أنواع الكوارث الطبيعية</h3>
      <ul>
        <li><strong>الزلازل:</strong> اهتزازات مفاجئة لسطح الأرض.</li>
        <li><strong>الفيضانات:</strong> ارتفاع منسوب المياه وغمر الأراضي.</li>
        <li><strong>الأعاصير:</strong> عواصف شديدة تسبب دمارًا واسعًا.</li>
        <li><strong>الحرائق البرية:</strong> حرائق غير مُسيطَر عليها في الغابات أو الأراضي.</li>
      </ul>
      <p>الكوارث الطبيعية تشكل تحديًا كبيرًا للبشرية، وتتطلب استعدادًا ووعيًا كبيرين.</p>
    `;
  });

  sendAlertButton.addEventListener('click', () => {
    alert('تنبيه طارئ: تم اكتشاف كارثة طبيعية في منطقتك. يرجى البقاء في أمان!');
  });
});
